# Custom Map Tiles

## Usage with MapLibre GL JS

```javascript
import maplibregl from 'maplibre-gl';

const map = new maplibregl.Map({
  container: 'map',
  style: {
    version: 8,
    sources: {
      'custom-map': {
        type: 'raster',
        tiles: ['http://localhost:8080/tiles/{z}/{x}/{y}.png'],
        tileSize: 256,
        maxzoom: 4
      }
    },
    layers: [
      { id: 'map-layer', type: 'raster', source: 'custom-map' }
    ]
  },
  center: [0, 0],
  zoom: 1
});
```

## Serving Tiles

Serve the tiles folder with any static file server:

```bash
npx serve tiles
```

## Tile Info

- Tile size: 256x256
- Max zoom: 4
- Original dimensions: 2434x3176
